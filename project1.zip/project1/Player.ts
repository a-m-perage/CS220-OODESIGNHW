//used in accounting
import { currentPlayer } from "./BlackJackMain";
import { Card } from './Deck';

//Class to manage player/dealer 
export class Player {

    //Fields go here
    name: string;
    score: number;
    ace: boolean;
    parray: any[];

    //ace bool used as flag
    constructor (name:string, score:number, ace:boolean, parray: any[]) {
        this.name = name;
        this.score = score;
        this.ace = ace;
        //array used to hold current cards
        this.parray = parray;
    }

    //function handles the adding of scores per player and the flagging of aces
    accounting(object: Card): void {

        if (object.Ace == true) {
            //send notice to ace flag func in Deck
            
        } 
        currentPlayer.score += object.value;
        
        
    }

}